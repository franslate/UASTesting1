# basic-automation

<b>Nama</b> : Ade Mardiansyah
<p><b>Kelas</b> : 07 TPLE 010</p>
<p><b>NIM</b> : 201011400194</p>

# Tugas Uas 3
<p>testing basic automation</p>
